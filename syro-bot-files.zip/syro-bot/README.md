# Syro Bot

An AI-powered Discord bot with slash commands and admin-managed server knowledge.

## Commands

- `/ask question:` Ask Syro a question.
- `/chat message:` Chat with Syro. Short per-user conversation context is kept in memory while the process is running.
- `/ttrain information:` Save a server fact (administrator only).
- `/tmemory` List recent saved facts (administrator only).
- `/tforget knowledge_id:` Delete a saved fact (administrator only).
- `/tpersonality personality:` Set the server's assistant style (administrator only).
- `/thelp` Show commands.

Discord requires slash-command names to be lowercase, so the training command appears as `/ttrain`, not `/tTrain`.

## 1. Create/configure the Discord application

1. Create an application in the Discord Developer Portal.
2. Under **Bot**, create/reset the bot token and keep it private.
3. Under **OAuth2 > URL Generator**, select `bot` and `applications.commands`.
4. Grant only the permissions needed, such as View Channels, Send Messages, Embed Links, and Read Message History.
5. Use the generated URL to add the bot to your server.

The bot uses Discord's default intents and does not need the privileged Message Content intent because it uses slash commands.

## 2. Create API credentials

Create an API key in your OpenAI Platform account. API usage may incur charges and is separate from a ChatGPT subscription. Set `OPENAI_MODEL` to a model identifier available to your API account.

## 3. Upload to GitHub

Upload the project files to your repository. Keep `.env` and all real credentials out of GitHub. `.env.example` contains placeholders only.

## 4. Deploy on Railway

1. In Railway, create a new project and choose **Deploy from GitHub Repo**.
2. Authorize Railway to access your GitHub account/repository if prompted.
3. Select this repository.
4. Open the service's **Variables** tab and add:
   - `DISCORD_TOKEN` = your Discord bot token
   - `OPENAI_API_KEY` = your OpenAI API key
   - `OPENAI_MODEL` = a model ID supported by your API account (default in this project: `gpt-5`)
   - `DATABASE_PATH` = `/data/syro.sqlite3`
5. Add a Railway Volume to the service and mount it at `/data`. This keeps training data across redeployments.
6. Deploy. Check the deployment logs for `Syro Bot logged in` and `Registered ... Discord slash commands`.

Railway UI labels and plan limits may change. A continuously running worker and persistent volume may require a paid Railway plan.

## 5. Local test (optional)

Use Python 3.11+:

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
copy .env.example .env
# Edit .env with your own secrets, then:
python bot.py
```

## Security and behaviour

- Never share your Discord token or API key in chat, screenshots, GitHub, or public logs. If exposed, reset it immediately.
- `/ttrain`, `/tmemory`, `/tforget`, and `/tpersonality` check Discord administrator permission. You can also add your Discord user ID to `OWNER_IDS`.
- Learned facts are stored separately per Discord server in SQLite.
- Saved facts are treated as reference data, not trusted instructions.
- Chat conversation context is temporary in process memory; it resets when the bot restarts.
- Syro answers using the configured AI API. API availability, model access, and billing depend on your provider account.
